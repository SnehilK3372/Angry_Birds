package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class Wood extends Block{

    Texture tex=new Texture(Gdx.files.internal("Blocks/Wood_vert.png"));
    Wood(){
        super(new Texture(Gdx.files.internal("Blocks/Wood_vert.png")));
    }
    Wood(Texture texture, float x, float y) {
        super(texture, x, y);
    }
}
