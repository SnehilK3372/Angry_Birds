package io.github.some_example_name;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Vector2;

public class Bird {
    private int health;
    private int power;
    private Vector2 location;
    private Texture texture;
    private TextureAtlas atlas;
    private Sprite sprite;

    public Bird(){

    }
    public Bird(Texture texture){
        this.texture=texture;
        this.sprite=new Sprite(texture);
    }
    public Bird(Texture texture, float x, float y){
        this.texture=texture;
        this.sprite=new Sprite(texture);
        this.location=new Vector2(x,y);
        sprite.setPosition(x,y);
    }
    public Bird(TextureAtlas atlas){
        this.atlas=atlas;
    }
    public void setTexture(Texture texture){
        this.texture=texture;
    }
    public Texture getTexture(){
        return this.texture;
    }
    public void setHealth(int health){
        this.health=health;
    }
    public Sprite getSprite(){
        return sprite;
    }
}
