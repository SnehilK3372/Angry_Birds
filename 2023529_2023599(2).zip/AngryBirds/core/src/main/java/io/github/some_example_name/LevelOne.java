package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.util.ArrayList;
import java.util.List;

final class LevelOne extends ScreenAdapter {
    Main game;//do not use stage/spritebatch from previous class
    private Texture background;
    private Texture pauseTex,playTex;
    private ImageButton pauseButton,playButton;
    private Texture overlayTex;
    private Stage menuStage;
    private Stage gameStage;
    private SpriteBatch spriteBatch;
    private InputMultiplexer inputMultiplexer;

    private BitmapFont abFont;
    private Skin skin;
    private Label pauseTitle;

    //private Table overlay;
    private Image overlay;
    private Image levelPaused;
    private Texture levelPause;

    private Texture slingshot;
    private Sprite slingshotSprite;

    private Texture exit;
    private ImageButton exitButton;

    private boolean isPaused=false;
    List<Bird> birdList=new ArrayList<>();
    List<Pig> pigList=new ArrayList<>();
    List<Block> blockLost=new ArrayList<>();
    Bird Red1;
    Bird Terence1;

    Pig pig1;


    Block Block1;
    Block Block2;
    Block Block3;
    Block Block4;

    Sprite blk1;
    Sprite blk2;



    LevelOne(Main game){
        this.game=game;
        inputMultiplexer=new InputMultiplexer();

        background=new Texture(Gdx.files.internal("Levels/Level1background.jpg"));
        spriteBatch=new SpriteBatch();

        menuStage = new Stage(new ScreenViewport());
        gameStage = new Stage(new ScreenViewport());

        slingshot= new Texture(Gdx.files.internal("Birds/Mythic_Slingshot.png"));
        slingshotSprite= new Sprite(slingshot);

        exit=new Texture(Gdx.files.internal("Buttons/exit.png"));
        TextureRegionDrawable reloadDraw=new TextureRegionDrawable(exit);
        exitButton =new ImageButton(reloadDraw);
        exitButton.setPosition(15,Gdx.graphics.getHeight()-exit.getHeight()-110 );

        exitButton.addListener(event->{
            if(exitButton.isPressed()){
                game.setScreen(new GameScreen(game));
                return true;
            }
            return false;
        });


        //gameStage.add(slingshotSprite);


        //overlay for the Pause, win and lose screens
//        overlay = new Table();
//        overlay.setFillParent(true);
//        overlay.setColor(0, 0, 0, 0.5f);
//        overlay.setVisible(false);//only true when menu is clicked
    }
    @Override
    public void show(){

//        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts/your_custom_font.ttf"));
//        FreeTypeFontParameter parameter = new FreeTypeFontParameter();
//        parameter.size = 32; // Set the desired font size
//        abFont = generator.generateFont(parameter); // Generate the font
//        generator.dispose();
//
//        skin =new Skin();
//        skin.add("abFont",abFont);
//
//        Label.LabelStyle labelStyle=new Label.LabelStyle();
//        labelStyle.font=skin.getFont("abFont");
//
//        pauseTitle=new Label("Level 1 - Paused",labelStyle);
//        pauseTitle.setPosition(400,400);
//
//        menuStage.addActor(pauseTitle);

        levelPause=new Texture(Gdx.files.internal("Buttons/Level1Pause.png"));
        levelPaused=new Image(levelPause);
        levelPaused.setPosition(400,600);
        menuStage.addActor(levelPaused);

        overlayTex=new Texture(Gdx.files.internal("Buttons/Overlay.png"));
        overlay = new Image(overlayTex);

        overlay.setVisible(false);

        //pause button
        pauseTex =new Texture(Gdx.files.internal("Buttons/pauseButton.png"));
        TextureRegionDrawable pauseDraw=new TextureRegionDrawable(pauseTex);
        pauseButton=new ImageButton(pauseDraw);
        pauseButton.setPosition(15,Gdx.graphics.getHeight()-pauseTex.getHeight()-10 );

        pauseButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                System.out.println("meow");
                isPaused = true;
                togglePause();
            }
        });

        //play button
        playTex =new Texture(Gdx.files.internal("Buttons/playGame2.png"));
        TextureRegionDrawable playDraw=new TextureRegionDrawable(playTex);
        playButton=new ImageButton(playDraw);
        playButton.setPosition(15,Gdx.graphics.getHeight()-playTex.getHeight()-10 );
        playButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                isPaused = false;
                togglePause();
            }
        });

        Red1=new Red(95,275);
        Terence1=new Terence(85,280);
        birdList.add(Red1);
        birdList.add(Terence1);

        pig1=new SmallPig();



        Block1= new Wood();
        Block2= new Wood();
        Block3= new Wood(new Texture(Gdx.files.internal("Blocks/Wood_hor.png")),500,50);
        Block4= new Wood(new Texture(Gdx.files.internal("Blocks/Wood_hor.png")),500,50);







        gameStage.addActor(pauseButton);

        menuStage.addActor(overlay);
        menuStage.addActor(exitButton);
        menuStage.addActor(playButton);





        inputMultiplexer.addProcessor(gameStage);
        //inputMultiplexer.addProcessor(menuStage);
        Gdx.input.setInputProcessor(inputMultiplexer);

    }
    private void togglePause(){
        overlay.setVisible(isPaused);
        if (isPaused) {
            inputMultiplexer.addProcessor(menuStage);
            inputMultiplexer.removeProcessor(gameStage);
        } else {
            inputMultiplexer.addProcessor(gameStage);
            inputMultiplexer.removeProcessor(menuStage);
        }
    }

    @Override
    public void render(float delta){
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        spriteBatch.begin();
        spriteBatch.draw(background,0,0);
        spriteBatch.draw(slingshotSprite,95,180);
        spriteBatch.draw(Red1.getSprite(),103,245);
        spriteBatch.draw(Terence1.getSprite(),10,199);
        spriteBatch.draw(Block1.getSprite(),825,125);
        spriteBatch.draw(Block2.getSprite(),820+Block3.getSprite().getWidth(),125);
        spriteBatch.draw(Block3.getSprite(),825,125);
        spriteBatch.draw(Block4.getSprite(),825,125+Block1.getSprite().getHeight()-10);
        spriteBatch.draw(pig1.getSprite(),840,130);





        spriteBatch.end();

        if(!isPaused){
            gameStage.act(delta);
            gameStage.draw();

        }
        else{
            menuStage.act(delta);
            menuStage.draw();
        }



    }
    @Override
    public void dispose(){
        background.dispose();
        spriteBatch.dispose();
    }
}
