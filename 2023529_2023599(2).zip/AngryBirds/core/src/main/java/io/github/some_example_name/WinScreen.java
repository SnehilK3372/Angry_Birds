package io.github.some_example_name;

import com.badlogic.gdx.ScreenAdapter;

public class WinScreen extends ScreenAdapter{

}
