package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class Terence extends Bird{

    public Terence(){
        setTexture(new Texture(Gdx.files.internal("Birds/Terence1.png")));
        setHealth(15);
    }
    public Terence(float x, float y){
        super(new Texture(Gdx.files.internal("Birds/Terence1.png")),x,y);
    }
}
