package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class GameScreen extends ScreenAdapter {
    Main game;
    Stage staticStage;
    Stage scrollStage;

    private Texture backgroundTex;
    private Texture settings;
    private ImageButton settingsButton;

    private Texture Level1;
    private ImageButton Level1Button;

    private Texture Level2;
    private ImageButton Level2Button;

    private Texture Level3;
    private ImageButton Level3Button;

    private OrthographicCamera camera;
    private float levelWidth;
    private float velocityX = 0f; // Track drag velocity
    private final float damping = 0.9f;

    private InputMultiplexer inputMultiplexer;



    GameScreen(Main game){
        this.game=game;

        camera= new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(camera.viewportWidth/ 2,camera.viewportHeight/2,0);// set cam position

        scrollStage=new Stage(new FitViewport(Gdx.graphics.getWidth(),Gdx.graphics.getHeight(),camera));
        staticStage=new Stage(new ScreenViewport());


        settings=new Texture(Gdx.files.internal("Buttons/Settings.png"));
        TextureRegionDrawable settingsDraw=new TextureRegionDrawable(settings);
        settingsButton=new ImageButton(settingsDraw);
        settingsButton.setPosition(15,10);

        backgroundTex = new Texture(Gdx.files.internal("Backgrounds/mount_wide1.jpg"));//image edited to fit
        levelWidth=backgroundTex.getWidth();



        Level1=new Texture(Gdx.files.internal("Levels/Level1_notfinal.jpg.png"));
        TextureRegionDrawable Level1Draw=new TextureRegionDrawable(Level1);
        Level1Button=new ImageButton(Level1Draw);
        Level1Button.setPosition(Level1Button.getWidth()/2 -30,(Gdx.graphics.getHeight()-Level1Button.getHeight())/2f+20);

        Level1Button.addListener(event -> {
            if(Level1Button.isPressed()){
                this.game.setScreen(new LevelOne(game));
                return true;
            }
            return false;
        });

        Level2 = new Texture(Gdx.files.internal("Levels/level2_notfinal.png"));
        TextureRegionDrawable Level2Draw=new TextureRegionDrawable(Level2);
        Level2Button=new ImageButton(Level2Draw);
        Level2Button.setPosition(1100,(Gdx.graphics.getHeight()-Level1Button.getHeight())/2f+15);

        Level2Button.addListener(event->{
            if(Level2Button.isPressed()){//not set yet
                return true;
            }
            return false;
        });


    }
    @Override
    public void show(){

        inputMultiplexer=new InputMultiplexer();
        inputMultiplexer.addProcessor(scrollStage);
        inputMultiplexer.addProcessor(staticStage);
        inputMultiplexer.addProcessor(new InputAdapter(){
           //private int lastX=-1; // static scroll
           @Override

           public boolean touchDragged(int ScreenX, int ScreenY, int pointer){
               //static scroll
//               if(lastX!=-1){
//                   int deltaX=ScreenX-lastX;
//                   camera.position.x-=deltaX;
//               }
//               lastX=ScreenX;
               velocityX = -Gdx.input.getDeltaX() * 60f;

               return true;

           }
           @Override
            public boolean touchUp(int x, int y, int pointer,int button){//behaviour when mouse releases
               velocityX*=damping;
               //lastX=-1;
               return true;
           }
        });

        Gdx.input.setInputProcessor(inputMultiplexer);//input multiplexer has input from 3 sources: 2 stages and 1 for scroll

        scrollStage.addActor(Level1Button);
        scrollStage.addActor(Level2Button);


        staticStage.addActor(settingsButton);

    }
    @Override
    public void render(float delta){
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.position.x += velocityX * delta;
        velocityX *= damping;

        camera.position.x = Math.max(camera.viewportWidth / 2, Math.min(levelWidth - camera.viewportWidth / 2, camera.position.x));
        game.spriteBatch.setProjectionMatrix(camera.combined);
        camera.update();

        game.spriteBatch.begin();//sprite batch for scrollable element
        game.spriteBatch.draw(backgroundTex,0,0);
        game.spriteBatch.end();

        scrollStage.act(delta);
        scrollStage.draw();

        staticStage.act(delta);
        staticStage.draw();

    }
    @Override
    public void resize(int width, int height){

    }
    @Override
    public void pause(){

    }
    @Override
    public void resume(){

    }
    @Override
    public void hide(){

    }
    @Override
    public void dispose(){
        game.spriteBatch.dispose();
        backgroundTex.dispose();
    }

}
