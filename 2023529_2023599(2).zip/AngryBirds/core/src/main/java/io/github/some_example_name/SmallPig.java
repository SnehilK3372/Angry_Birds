package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class SmallPig extends Pig{
    public SmallPig(){
        super(new Texture(Gdx.files.internal("Birds/PigKing.png")));
        setHealth(15);
    }
    public SmallPig(float x, float y){
        super(new Texture(Gdx.files.internal("Birds/PigKing.png")),x,y);
    }
}
