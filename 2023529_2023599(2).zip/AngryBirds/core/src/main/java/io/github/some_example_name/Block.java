package io.github.some_example_name;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;

public class Block {
    private int health;
    private Vector2 location;
    private Texture texture;
    private Sprite sprite;

    Block(Texture texture){
        this.texture=texture;
        this.sprite=new Sprite(texture);

    }
    Block(Texture texture, float x, float y){
        this.texture=texture;
        this.sprite=new Sprite(texture);
        sprite.setPosition(x,y);
    }
    public Sprite getSprite(){
        return sprite;
    }
}
