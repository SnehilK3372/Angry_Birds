package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class Glass extends Block{

    Texture tex=new Texture(Gdx.files.internal(""));
    Glass(){
        super(new Texture(Gdx.files.internal("")));
    }
    Glass(Texture texture, float x, float y) {
        super(texture, x, y);
    }
}
