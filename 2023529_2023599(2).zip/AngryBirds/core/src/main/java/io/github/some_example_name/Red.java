package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class Red extends Bird{

    public Red(){
        super(new Texture(Gdx.files.internal("Birds/Red1.png")));
        setHealth(5);
    }
    public Red(float x, float y){
        super(new Texture(Gdx.files.internal("Birds/Red2.png")),x,y);
    }

}
