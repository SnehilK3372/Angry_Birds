package io.github.some_example_name;

import com.badlogic.gdx.ScreenAdapter;

public class LoseScreen extends ScreenAdapter {
}
